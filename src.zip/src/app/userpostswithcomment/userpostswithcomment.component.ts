import { Component, OnInit } from '@angular/core';
import { PostsService } from '../services/posts.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-userpostswithcomment',
  templateUrl: './userpostswithcomment.component.html',
  styleUrls: ['./userpostswithcomment.component.css']
})
export class UserpostswithcommentComponent implements OnInit {
  posts:any[];
 
  message="";
 
  userId=0;
  constructor(private ps:PostsService,private route:ActivatedRoute) { }

  ngOnInit() {
    this.userId=this.route.snapshot.queryParams.userId;

   if(this.userId)
   this.getAllPostsByUserId();
   else
   this.getAllPosts();
  }
  getAllPosts(){
    this.ps.getAllPosts()
           .subscribe(response=>this.posts=response,error=>this.message=error);
  }

  getAllPostsByUserId(){
    this.ps.getAllPostByUserId(this.userId)
           .subscribe(response=>this.posts=response,error=>this.message=error);
  }
}
