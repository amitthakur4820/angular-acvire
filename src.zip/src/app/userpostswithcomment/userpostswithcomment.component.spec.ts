import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserpostswithcommentComponent } from './userpostswithcomment.component';

describe('UserpostswithcommentComponent', () => {
  let component: UserpostswithcommentComponent;
  let fixture: ComponentFixture<UserpostswithcommentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserpostswithcommentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserpostswithcommentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
