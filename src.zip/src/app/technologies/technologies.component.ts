import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-technologies',
  templateUrl: './technologies.component.html',
  styleUrls: ['./technologies.component.css']
})
export class TechnologiesComponent  {

  title="Top 5 technologies";

  technologies=[
    {id:1,name:'Angular',likes:0,dislikes:0},
    {id:2,name:'AWS',likes:0,dislikes:0},
    {id:3,name:'Spring',likes:0,dislikes:0},
    {id:4,name:'Micro services',likes:0,dislikes:0},
    {id:5,name:'ML',likes:0,dislikes:0},
  ];



  incrementLikes(t){
    t.likes++;
  }
  
  incrementDislikes(t){
    t.dislikes++;
  }
  






  constructor() { 
    console.log("############  TechnologiesComponent  created ###########");

  }

  ngOnInit() {
    console.log("############  TechnologiesComponent  initialized ###########");
    
  }
  
  ngOnDestroy() {
    console.log("############  TechnologiesComponent  dsestroyed ###########");
   }
}
