import { Component } from '@angular/core';

@Component({
  selector: 'app-root', //where to inject
  templateUrl: './app.component.html',//where to display
 //   template:'<h1>Hello World  :{{title}}</h1>',
 styleUrls: ['./app.component.css'] //how to display
})
export class AppComponent {
  title = 'my-app';//what to dusplay
}
