import { Component, OnInit } from '@angular/core';
import { TodosService } from '../services/todos.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-todos',
  templateUrl: './todos.component.html',
  styleUrls: ['./todos.component.css']
})
export class TodosComponent implements OnInit {

  title="TODOS Table"; 

  todos:any[];
 
  message="";
 
  userId=0;

   constructor(private todo:TodosService,private route:ActivatedRoute) { 
     console.log("############  TODoComponent  created ###########");
 
   }
 
   ngOnInit() {
     
    this.userId=this.route.snapshot.queryParams.userId;

   if(this.userId)
   this.getAllPostsByUserId();
   else
   this.getAllTodos();


     console.log("############  TODoComponent  initialized ###########"+this.userId);
     
   }
   
   ngOnDestroy() {
     console.log("############  TODoComponent  dsestroyed ###########");
    }
   
 
    getAllTodos(){
      this.todo.getAllTodos()
             .subscribe(response=>this.todos=response,error=>this.message=error);
    }

    getAllPostsByUserId(){
      this.todo.getAllTodoByUserId(this.userId)
             .subscribe(response=>this.todos=response,error=>this.message=error);
    }

 
}
