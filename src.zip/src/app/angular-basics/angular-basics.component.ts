import { Component, OnInit, OnDestroy } from '@angular/core';
import { Observable, Subscriber } from 'rxjs';

@Component({
  selector: 'app-angular-basics',
  templateUrl: './angular-basics.component.html',
  styleUrls: ['./angular-basics.component.css']
})
export class AngularBasicsComponent implements OnInit,OnDestroy {
    
  title = 'Angular 8 Basics';
  colors = ['RED', 'GREEN', 'BLUE', 'MAGENTA', 'ORANGE'];
  day = 1;
  min = 1;
  max = 8;
  time = new Observable<string>((s:Subscriber<string>)=>{
    
  setInterval(()=>{
    s.next(new Date().toLocaleString());
  },1000);
  
  });


  show = true;
  hide = false;

  employee = {
    id: 1011,
    name: 'Pradeep chinchole',
    salary: 12000.443534534,
    doj: new Date("January 31,2017"),
    variable: 0.15,
    mobile: '9158652627',
    pan: 'Amxdd9834f',
    city: 'Pune'
  };





  showHide(){
    this.hide=!this.hide;
  }


  constructor() { 
    console.log("############  AngularBasicsComponent  created ###########");

  }

  ngOnInit() {
    console.log("############  AngularBasicsComponent  initialized ###########");
    
  }
  
  ngOnDestroy() {
    console.log("############  AngularBasicsComponent  dsestroyed ###########");
   }
  

}
